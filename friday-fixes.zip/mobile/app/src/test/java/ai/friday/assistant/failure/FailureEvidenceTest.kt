package ai.friday.assistant.failure

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException

/**
 * The exported device report once said an engine scope failed without saying
 * what threw. These tests pin that the cause and the throw site now reach the
 * rendered diagnosis, and that the rendering stays one bounded line.
 */
class FailureEvidenceTest {

    private fun event(cause: String?, metadata: Map<String, String> = emptyMap()) = FailureEvent(
        id = "failure-test",
        timestamp = 1L,
        source = "test",
        subsystem = "ENGINE",
        operation = "friday-engine",
        severity = FailureSeverity.ERROR,
        category = FailureCategory.INTERNAL,
        message = "Engine scope 'friday-engine' contained an uncaught failure",
        cause = cause,
        metadata = metadata
    )

    private fun thrower(): Throwable = IllegalStateException("boom")

    @Test
    fun `describe is empty when the record carries no cause evidence`() {
        assertEquals("", FailureEvidence.describe(event(cause = null)))
    }

    @Test
    fun `describe names the cause and where it was thrown`() {
        val text = FailureEvidence.describe(
            event(
                cause = "IllegalStateException: boom",
                metadata = mapOf(FailureEvidence.STACK_TOP_KEY to FailureEvidence.stackTop(thrower()))
            )
        )
        assertTrue(text, text.contains("Cause: IllegalStateException: boom"))
        assertTrue(text, text.contains("Where: IllegalStateException at"))
        assertTrue(text, text.contains("FailureEvidenceTest.thrower"))
    }

    @Test
    fun `stackTop reports the root cause of a wrapped exception`() {
        val text = FailureEvidence.stackTop(RuntimeException("outer", IOException("disk full")))
        assertTrue(text, text.startsWith("RuntimeException at"))
        assertTrue(text, text.contains("root: IOException: disk full"))
    }

    @Test
    fun `describe stays on one bounded line`() {
        val text = FailureEvidence.describe(event(cause = "X: " + "a\nb ".repeat(2_000)))
        assertTrue(text.length <= FailureEvidence.MAX_LENGTH)
        assertTrue(!text.contains('\n'))
    }
}
